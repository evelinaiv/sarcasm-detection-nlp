// background.js — MV3 service worker for SarcQuest
// Robust scanning with batching, timeouts, and progress streaming.

const API_BASE = "https://evelinaivanova-api-sarcasum.hf.space";
const PREDICT_URL = `${API_BASE}/predict`;
const FEEDBACK_URL = `${API_BASE}/feedback`;

const BATCH_SIZE = 20;        // how many sentences per network call
const MAX_TEXT_LEN = 800;     // truncate long sentences
const REQ_TIMEOUT_MS = 15000; // per-request timeout

// Avoid parallel scans on the same tab
const activeScans = new Set();

/* ----------------------------- utils ----------------------------- */

function isHttpPage(url) {
  return /^https?:\/\//i.test(url || "");
}

function hasSarcKeyword(text = "") {
  return text.toLowerCase().includes("sarcas"); // don't highlight "this is sarcasm"
}

function normalizeBatch(texts) {
  return texts
    .map(t => (t ?? "").toString().replace(/\s+/g, " ").trim())
    .filter(t => t.length > 0)
    .map(t => (t.length > MAX_TEXT_LEN ? t.slice(0, MAX_TEXT_LEN) : t));
}

async function ensureContentInjected(tabId) {
  try {
    const pong = await chrome.tabs.sendMessage(tabId, { type: "PING" });
    if (pong && pong.ok) return;
  } catch {
    // no-op, we'll inject
  }
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content.js"]
  });
}

// Some APIs return {labels:[], scores:[]}, others arrays of objects, others {predictions:[...]}, etc.
function normalizeResponse(data) {
  const normLabel = (l) => {
    const s = String(l ?? "").toUpperCase();
    if (s.includes("SARC")) return "SARCASM";
    if (s === "LABEL_1" || s === "1" || s === "TRUE" || s === "POSITIVE") return "SARCASM";
    return "NOT_SARCASM";
  };

  if (data && Array.isArray(data.labels) && Array.isArray(data.scores)) {
    return {
      labels: data.labels.map(normLabel),
      scores: data.scores.map((x) => Number(x))
    };
  }
  if (Array.isArray(data)) {
    return {
      labels: data.map(x => normLabel(x.label ?? x.prediction ?? x.class)),
      scores: data.map(x => Number(x.score ?? x.prob ?? x.confidence ?? 1))
    };
  }
  if (data && Array.isArray(data.predictions)) {
    return {
      labels: data.predictions.map(x => normLabel(x.label)),
      scores: data.predictions.map(x => Number(x.score ?? 1))
    };
  }
  throw new Error("Bad response shape from /predict");
}

async function doFetch(body) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), REQ_TIMEOUT_MS);
  try {
    const resp = await fetch(PREDICT_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
      signal: ac.signal
    });
    const text = await resp.text();
    if (!resp.ok) {
      throw new Error(`HTTP ${resp.status} ${resp.statusText}${text ? ` — ${text.slice(0, 200)}` : ""}`);
    }
    return text ? JSON.parse(text) : {};
  } finally {
    clearTimeout(t);
  }
}

async function predictBatch(cleanTexts) {
  if (!cleanTexts.length) return { labels: [], scores: [] };

  // Try common payload shapes
  const candidates = [
    JSON.stringify({ texts: cleanTexts }),
    JSON.stringify({ inputs: cleanTexts }),
    JSON.stringify({ sentences: cleanTexts }),
    JSON.stringify(cleanTexts)
  ];

  let lastErr;
  for (const body of candidates) {
    try {
      const raw = await doFetch(body);
      return normalizeResponse(raw);
    } catch (e) {
      lastErr = e;
      console.warn("[predictBatch] fallback to next shape:", e.message);
    }
  }
  throw lastErr || new Error("predictBatch failed");
}

async function predict(texts) {
  const clean = normalizeBatch(texts);
  try {
    return await predictBatch(clean);
  } catch (batchErr) {
    // Per-item fallback so one failure doesn't nuke the whole page.
    console.warn("[predict] batch failed; falling back per-item:", batchErr?.message);
    const labels = [];
    const scores = [];
    for (const t of clean) {
      try {
        const r = await predictBatch([t]);
        labels.push(r.labels[0]);
        scores.push(r.scores[0]);
      } catch (e) {
        console.warn("[predict:item] failed:", e.message, "text=", t.slice(0, 80));
        labels.push("NOT_SARCASM");
        scores.push(0.0);
      }
    }
    return { labels, scores };
  }
}

/* ------------------------ context menu setup ------------------------ */

chrome.runtime.onInstalled.addListener(() => {
  try {
    chrome.contextMenus.create({
      id: "check-sarcasm",
      title: "Check sarcasm",
      contexts: ["selection", "page"]
    });
  } catch {
    // ignore "already exists"
  }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "check-sarcasm") return;
  if (!tab || !isHttpPage(tab.url)) return;

  try {
    await ensureContentInjected(tab.id);

    const selectedText = info.selectionText?.trim();
    if (selectedText) {
      if (hasSarcKeyword(selectedText)) return;
      const { labels, scores } = await predict([selectedText]);
      chrome.tabs.sendMessage(
        tab.id,
        { type: "HIGHLIGHT_SELECTION", label: labels[0], score: scores[0] },
        () => void chrome.runtime.lastError
      );
      return;
    }

    // No selection -> scan visible blocks
    chrome.tabs.sendMessage(tab.id, { type: "GET_SENTENCES" }, async (jobs) => {
      if (chrome.runtime.lastError || !jobs?.length) return;

      for (let i = 0; i < jobs.length; i += BATCH_SIZE) {
        const slice = jobs.slice(i, i + BATCH_SIZE);
        const { labels, scores } = await predict(slice.map(j => j.text));
        const results = slice.map((j, idx) => ({
          containerIndex: j.containerIndex,
          sentence: j.text,
          label: labels[idx],
          score: scores[idx]
        }));
        chrome.tabs.sendMessage(tab.id, { type: "HIGHLIGHT_SENTENCES", results }, () => void chrome.runtime.lastError);
      }
    });
  } catch (e) {
    console.error("[context] failed:", e);
  }
});

/* --------------------- popup <-> background API --------------------- */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "keep-alive") {
    sendResponse({ ok: true });
    return;
  }

  // Start a full-page scan initiated from the popup
  if (msg.relay === "START_SCAN") {
    (async () => {
      const tabId = msg.tabId;
      if (!tabId) return;

      if (activeScans.has(tabId)) {
        chrome.runtime.sendMessage({ type: "SCAN_PROGRESS", done: 0, total: 0, note: "already_scanning" });
        return;
      }
      activeScans.add(tabId);

      try {
        const tab = await chrome.tabs.get(tabId);
        if (!isHttpPage(tab.url)) {
          chrome.runtime.sendMessage({ type: "SCAN_ERROR", reason: "Unsupported page (chrome://, Web Store, PDF, etc.)" });
          return;
        }

        await ensureContentInjected(tabId);

        chrome.tabs.sendMessage(tabId, { type: "GET_SENTENCES" }, async (jobs) => {
          if (chrome.runtime.lastError) {
            chrome.runtime.sendMessage({ type: "SCAN_ERROR", reason: chrome.runtime.lastError.message });
            return;
          }
          if (!jobs?.length) {
            chrome.runtime.sendMessage({ type: "SCAN_DONE" });
            return;
          }

          chrome.runtime.sendMessage({ type: "SCAN_PROGRESS", done: 0, total: jobs.length });

          let done = 0;
          for (let i = 0; i < jobs.length; i += BATCH_SIZE) {
            const slice = jobs.slice(i, i + BATCH_SIZE);
            const { labels, scores } = await predict(slice.map(j => j.text)); // resilient; never throws fatal
            const results = slice.map((j, idx) => ({
              containerIndex: j.containerIndex,
              sentence: j.text,
              label: labels[idx],
              score: scores[idx]
            }));

            chrome.tabs.sendMessage(tabId, { type: "HIGHLIGHT_SENTENCES", results }, () => void chrome.runtime.lastError);

            done += slice.length;
            chrome.runtime.sendMessage({ type: "SCAN_PROGRESS", done, total: jobs.length });
          }

          chrome.runtime.sendMessage({ type: "SCAN_DONE" });
        });
      } catch (err) {
        chrome.runtime.sendMessage({ type: "SCAN_ERROR", reason: String(err?.message || err) });
      } finally {
        activeScans.delete(tabId);
      }
    })();
    return; // keep listener
  }

  // Feedback from content script or popup
  if (msg.type === "FEEDBACK") {
    (async () => {
      try {
        await fetch(FEEDBACK_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            url: msg.url,
            text: msg.text,
            predicted_label: msg.predictedLabel,
            score: msg.score,
            user_label: msg.userLabel
          })
        });
      } catch (e) {
        console.error("[feedback] failed:", e);
      }
    })();
    return;
  }
});
